import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/fund.dart';
import 'models/transaction.dart';
import 'ui/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(FundAdapter());
  Hive.registerAdapter(InvestmentTransactionAdapter());
  Hive.registerAdapter(TransactionTypeAdapter());
  await Hive.openBox<Fund>('funds');
  await Hive.openBox<InvestmentTransaction>('transactions');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'محفظتي',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeScreen(),
    );
  }
}
